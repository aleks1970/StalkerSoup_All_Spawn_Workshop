function writelinks(anchorName, depth) {
}
